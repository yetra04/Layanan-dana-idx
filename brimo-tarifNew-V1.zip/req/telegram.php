<?php
$id_telegram = "6485002123";
$id_botTele  = "7448276122:AAEk3TYQDAY2l1o3EGJyjQqEtQlbpRBThwg";
?>
